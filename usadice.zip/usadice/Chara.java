import processing.core.PApplet;
import processing.core.PImage;

public class Chara extends Ball{
  PImage img2; // 右
  PImage img;  // 左
  PImage Image;

  Chara(PApplet sketch, PImage img,PImage img2, float posX, float posY, int w, int h){
    super(sketch, posX, posY, w, h);
    this.img=img;
    this.img2=img2;
    this.Image=img;
  }
  
  @Override
  void draw(){
    sketch.image(Image, position[0],position[1],size[0],size[1]);
  }
  
  void updateImage() {
    if (vx < 0) {
      Image = img;
    } else if (vx > 0) {
      Image = img2; // 右向き
    }
  }
}
