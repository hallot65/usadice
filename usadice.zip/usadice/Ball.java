import processing.core.PApplet;
import processing.core.PImage;
class Ball {
  PApplet sketch;
  float position[] = new float[2];
  int size[] = new int[2];
  double vx;
  double f=0.9;
  double vy;
  
  
  Ball(PApplet sketch,float posX, float posY, int w, int h){
    this.sketch = sketch;
    position[0] = posX;
    position[1] = posY;
    size[0] = w;
    size[1] = h;
  }
  
  void gravity(){
  
    position[1]++;
    position[0]+=vx;
    position[1]+=vy;
    vy=vy+0.98;
    vx *= f;
  
  }

  void collision(){
    if(position[0]<30) position[0]=30;
    if(position[0]>265) position[0]=265;
    if(position[1]<30) position[1]=30;
    if(position[1]>300){
      position[1]=300;
      vy=vy*-0.25;
    }
  
  }

  void keyPressed(char key){
    if(key =='w'&& position[1]==300){
      vy=-12;
    }else if(key =='a'){
      vx=-5;
    }else if(key =='d'){
      vx=5;
    }
  }


  void draw() {
    //sketch.fill(col[0],col[1],col[2]);
    sketch.ellipse(position[0], position[1], size[0], size[1]); // 左上座標、幅、高さ

  }


}
